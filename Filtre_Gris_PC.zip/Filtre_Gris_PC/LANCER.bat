@echo off
setlocal EnableExtensions DisableDelayedExpansion
title Filtre Gris PC

set "FG_DIR=%~dp0"
set "FG_EXE=%~dp0FiltreGris.exe"
set "FG_SOURCE=%~dp0FiltreGris.cs"
set "FG_LOG=%~dp0compilation.log"
set "FG_CSC="

if exist "%FG_EXE%" goto launch
if not exist "%FG_SOURCE%" goto missing_source

if exist "%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\csc.exe" set "FG_CSC=%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not defined FG_CSC if exist "%SystemRoot%\Microsoft.NET\Framework\v4.0.30319\csc.exe" set "FG_CSC=%SystemRoot%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
if not defined FG_CSC goto missing_compiler

copy /y nul "%FG_LOG%" >nul 2>&1
if errorlevel 1 goto not_writable

echo Premier lancement : preparation du programme...
echo Cela prend normalement quelques secondes.
echo.
echo Compilation locale de FiltreGris.cs.>"%FG_LOG%"
"%FG_CSC%" /nologo /target:winexe /platform:anycpu /optimize+ /debug- /codepage:65001 /utf8output /reference:System.dll /reference:System.Core.dll /reference:System.Drawing.dll /reference:System.Windows.Forms.dll /reference:System.Xml.dll /out:"%FG_EXE%" "%FG_SOURCE%" >>"%FG_LOG%" 2>&1
if errorlevel 1 goto compile_failed
if not exist "%FG_EXE%" goto compile_failed

:launch
start "" /D "%FG_DIR%" "%FG_EXE%" --show
if errorlevel 1 goto launch_failed
exit /b 0

:missing_source
echo [ERREUR] Le fichier FiltreGris.cs est introuvable.
echo.
echo Faites un clic droit sur le ZIP, puis choisissez "Extraire tout".
echo Ouvrez le dossier extrait et double-cliquez sur LANCER.bat.
echo Gardez tous les fichiers du ZIP ensemble dans ce dossier.
echo.
echo Dossier utilise :
echo "%FG_DIR%"
goto failure

:missing_compiler
echo [ERREUR] Le compilateur .NET Framework 4.x est introuvable.
echo.
echo Ce programme utilise .NET Framework fourni avec Windows 10/11.
echo Verifiez ou reparez ce composant dans Windows, puis relancez.
echo Aucune installation ni aucun telechargement n'ont ete effectues.
goto failure

:not_writable
echo [ERREUR] Impossible d'ecrire dans le dossier du programme.
echo.
echo Extrayez le ZIP dans un dossier personnel, par exemple Documents,
echo puis lancez LANCER.bat depuis ce nouveau dossier.
echo Le lancement en administrateur n'est pas necessaire.
echo.
echo Dossier utilise :
echo "%FG_DIR%"
goto failure

:compile_failed
echo [ERREUR] La preparation du programme a echoue.
echo.
echo Details de la compilation :
echo.
type "%FG_LOG%"
echo.
echo Le journal complet est disponible ici :
echo "%FG_LOG%"
echo Vous pouvez transmettre ce fichier pour obtenir de l'aide.
goto failure

:launch_failed
echo [ERREUR] Windows n'a pas pu ouvrir FiltreGris.exe.
echo.
echo Verifiez que tous les fichiers ont ete extraits du ZIP.
echo Vous pouvez aussi ouvrir FiltreGris.exe directement pour voir
echo le message affiche par Windows.
goto failure

:failure
echo.
pause
exit /b 1
