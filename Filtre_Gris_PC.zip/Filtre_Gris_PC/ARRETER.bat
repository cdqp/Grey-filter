@echo off
setlocal EnableExtensions DisableDelayedExpansion
title Arreter Filtre Gris PC

set "FG_EXE=%~dp0FiltreGris.exe"
if not exist "%FG_EXE%" goto missing_program

"%FG_EXE%" --quit
if errorlevel 1 goto quit_failed
exit /b 0

:missing_program
echo [INFO] FiltreGris.exe est introuvable dans ce dossier.
echo.
echo S'il est actif, quittez le filtre avec son icone pres de l'horloge,
echo ou ouvrez ARRETER.bat dans le dossier utilise pour le lancer.
echo Ce bouton ne ferme aucun autre programme.
goto failure

:quit_failed
echo [ERREUR] La demande d'arret n'a pas pu etre transmise.
echo.
echo Utilisez l'icone Filtre Gris pres de l'horloge pour quitter.
echo Ce bouton ne ferme aucun autre programme.
goto failure

:failure
echo.
pause
exit /b 1
