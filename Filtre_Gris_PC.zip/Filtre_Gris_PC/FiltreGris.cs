﻿// Filtre Gris PC 1.0 - application Windows portable, C# 5 / .NET Framework 4.x.
// Aucun reseau, aucun changement de pilote, de gamma ou de luminosite materielle.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using System.Security.Principal;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using Microsoft.Win32;

[assembly: System.Reflection.AssemblyTitle("Filtre Gris PC")]
[assembly: System.Reflection.AssemblyDescription("Filtre visuel gris ou noir a opacite reglable")]
[assembly: System.Reflection.AssemblyVersion("1.0.0.0")]
[assembly: System.Reflection.AssemblyFileVersion("1.0.0.0")]

namespace FiltreGrisPC
{
    internal static class Program
    {
        internal static ControlWindow CurrentWindow;

        [STAThread]
        private static int Main(string[] args)
        {
            try
            {
                string sid = WindowsIdentity.GetCurrent().User.Value;
                string prefix = "Local\\FiltreGrisPC_" + sid + "_" + Process.GetCurrentProcess().SessionId;
                using (EventWaitHandle show = new EventWaitHandle(false, EventResetMode.AutoReset, prefix + "_Show"))
                using (EventWaitHandle quit = new EventWaitHandle(false, EventResetMode.AutoReset, prefix + "_Quit"))
                {
                    if (Array.Exists(args, delegate(string a) { return a.Equals("--quit", StringComparison.OrdinalIgnoreCase); }))
                    {
                        quit.Set();
                        return 0;
                    }
                    bool first;
                    using (Mutex instance = new Mutex(true, prefix + "_Running", out first))
                    {
                        if (!first)
                        {
                            show.Set();
                            return 0;
                        }
                        try
                        {
                            Native.InitializeDpi();
                            Application.EnableVisualStyles();
                            Application.SetCompatibleTextRenderingDefault(false);
                            Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
                            Application.ThreadException += OnUiException;
                            // Le panneau laisse Windows adapter son echelle. Les filtres utilisent
                            // un contexte distinct en pixels physiques, y compris en DPI mixtes.
                            using (new DpiScope(Native.DPI_SYSTEM))
                            {
                                CurrentWindow = new ControlWindow(show, quit);
                                IntPtr ensureControlHandle = CurrentWindow.Handle;
                            }
                            Application.Run(CurrentWindow);
                        }
                        finally
                        {
                            if (CurrentWindow != null) CurrentWindow.Dispose();
                            CurrentWindow = null;
                            Application.ThreadException -= OnUiException;
                            instance.ReleaseMutex();
                        }
                    }
                }
                return 0;
            }
            catch (Exception ex)
            {
                ShowError(ex);
                return 1;
            }
        }

        private static void OnUiException(object sender, ThreadExceptionEventArgs e)
        {
            if (CurrentWindow != null) CurrentWindow.RemoveFilters();
            ShowError(e.Exception);
            if (CurrentWindow != null && !CurrentWindow.IsDisposed) CurrentWindow.Close();
            Application.Exit();
        }

        private static void ShowError(Exception ex)
        {
            string details = ex.Message;
            try
            {
                Directory.CreateDirectory(UserSettings.DirectoryPath);
                string log = Path.Combine(UserSettings.DirectoryPath, "erreur.log");
                File.WriteAllText(log, DateTime.Now.ToString("s") + Environment.NewLine + ex, Encoding.UTF8);
                details += "\r\n\r\nDétails enregistrés dans :\r\n" + log;
            }
            catch { }
            MessageBox.Show("Le filtre a été arrêté.\r\n\r\n" + details,
                "Filtre Gris PC", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    internal sealed class UserSettings
    {
        internal int Opacity = 35;
        internal int Shade = 1;
        internal string Monitor = "all";
        internal bool Enabled = true;
        internal static string DirectoryPath
        {
            get { return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "FiltreGrisPC"); }
        }
        internal static int Clamp(int value, int min, int max) { return Math.Max(min, Math.Min(max, value)); }

        internal static UserSettings Load()
        {
            UserSettings settings = new UserSettings();
            try
            {
                string file = Path.Combine(DirectoryPath, "reglages.ini");
                if (!File.Exists(file) || new FileInfo(file).Length > 8192) return settings;
                foreach (string line in File.ReadAllLines(file, Encoding.UTF8))
                {
                    int equal = line.IndexOf('=');
                    if (equal < 1) continue;
                    string key = line.Substring(0, equal).Trim();
                    string value = line.Substring(equal + 1).Trim();
                    int number;
                    if (key == "opacity" && Int32.TryParse(value, out number)) settings.Opacity = Clamp(number, 0, 90);
                    if (key == "shade" && Int32.TryParse(value, out number)) settings.Shade = Clamp(number, 0, 2);
                    if (key == "monitor" && value.Length > 0 && value.Length < 80) settings.Monitor = value;
                    if (key == "enabled") settings.Enabled = value != "0";
                }
            }
            catch { /* Un fichier absent ou illisible ne doit pas empecher le lancement. */ }
            return settings;
        }

        internal bool Save()
        {
            string temp = null;
            try
            {
                Directory.CreateDirectory(DirectoryPath);
                string file = Path.Combine(DirectoryPath, "reglages.ini");
                temp = Path.Combine(DirectoryPath, "reglages.tmp");
                string content = "opacity=" + Opacity.ToString(CultureInfo.InvariantCulture)
                    + "\r\nshade=" + Shade.ToString(CultureInfo.InvariantCulture)
                    + "\r\nmonitor=" + Monitor + "\r\nenabled=" + (Enabled ? "1" : "0") + "\r\n";
                File.WriteAllText(temp, content, new UTF8Encoding(false));
                if (File.Exists(file)) File.Replace(temp, file, null);
                else File.Move(temp, file);
                return true;
            }
            catch { return false; }
            finally { try { if (temp != null && File.Exists(temp)) File.Delete(temp); } catch { } }
        }
    }

    internal sealed class DisplayInfo
    {
        internal string Device;
        internal Rectangle Bounds;
        internal bool Primary;
        internal string Label;
        public override string ToString() { return Label; }
    }

    internal sealed class DpiScope : IDisposable
    {
        private IntPtr previous;
        internal DpiScope(IntPtr requested)
        {
            try
            {
                previous = Native.SetThreadDpiAwarenessContext(requested);
                if (previous == IntPtr.Zero && requested == Native.DPI_PER_MONITOR_V2)
                    previous = Native.SetThreadDpiAwarenessContext(Native.DPI_PER_MONITOR);
            }
            catch (EntryPointNotFoundException) { }
            catch (DllNotFoundException) { }
        }
        public void Dispose()
        {
            if (previous == IntPtr.Zero) return;
            Native.SetThreadDpiAwarenessContext(previous);
            previous = IntPtr.Zero;
        }
    }

    internal static class Native
    {
        internal static readonly IntPtr DPI_SYSTEM = new IntPtr(-2);
        internal static readonly IntPtr DPI_PER_MONITOR = new IntPtr(-3);
        internal static readonly IntPtr DPI_PER_MONITOR_V2 = new IntPtr(-4);
        internal static readonly IntPtr HWND_TOPMOST = new IntPtr(-1);
        internal const int WS_EX_TRANSPARENT = 0x00000020;
        internal const int WS_EX_TOOLWINDOW = 0x00000080;
        internal const int WS_EX_LAYERED = 0x00080000;
        internal const int WS_EX_NOACTIVATE = 0x08000000;
        internal const uint SWP_NOSIZE = 0x0001;
        internal const uint SWP_NOMOVE = 0x0002;
        internal const uint SWP_NOACTIVATE = 0x0010;
        internal const uint SWP_NOOWNERZORDER = 0x0200;

        [StructLayout(LayoutKind.Sequential)]
        internal struct RECT { public int Left, Top, Right, Bottom; }
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        internal struct MONITORINFOEX
        {
            public int cbSize;
            public RECT rcMonitor;
            public RECT rcWork;
            public uint dwFlags;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)]
            public string szDevice;
        }
        private delegate bool MonitorEnumProc(IntPtr monitor, IntPtr hdc, ref RECT rect, IntPtr data);
        [DllImport("user32.dll")]
        private static extern bool EnumDisplayMonitors(IntPtr hdc, IntPtr clip, MonitorEnumProc callback, IntPtr data);
        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        private static extern bool GetMonitorInfo(IntPtr monitor, ref MONITORINFOEX info);
        [DllImport("user32.dll", SetLastError = true)]
        internal static extern bool SetWindowPos(IntPtr hWnd, IntPtr after, int x, int y, int cx, int cy, uint flags);
        [DllImport("user32.dll", SetLastError = true)]
        internal static extern bool RegisterHotKey(IntPtr hWnd, int id, uint modifiers, uint key);
        [DllImport("user32.dll", SetLastError = true)]
        internal static extern bool UnregisterHotKey(IntPtr hWnd, int id);
        [DllImport("user32.dll")]
        private static extern bool SetProcessDPIAware();
        [DllImport("shcore.dll")]
        private static extern int SetProcessDpiAwareness(int awareness);
        [DllImport("user32.dll")]
        private static extern bool SetProcessDpiAwarenessContext(IntPtr context);
        [DllImport("user32.dll")]
        internal static extern IntPtr SetThreadDpiAwarenessContext(IntPtr context);
        [DllImport("user32.dll")]
        private static extern bool DestroyIcon(IntPtr icon);

        internal static void InitializeDpi()
        {
            try { if (SetProcessDpiAwarenessContext(DPI_PER_MONITOR_V2)) return; }
            catch (EntryPointNotFoundException) { }
            catch (DllNotFoundException) { }
            try { if (SetProcessDpiAwareness(2) == 0) return; }
            catch (EntryPointNotFoundException) { }
            catch (DllNotFoundException) { }
            SetProcessDPIAware();
        }

        internal static List<DisplayInfo> GetDisplays()
        {
            List<DisplayInfo> displays = new List<DisplayInfo>();
            using (new DpiScope(DPI_PER_MONITOR_V2))
            {
                MonitorEnumProc callback = delegate(IntPtr monitor, IntPtr hdc, ref RECT rect, IntPtr data)
                {
                    MONITORINFOEX info = new MONITORINFOEX();
                    info.cbSize = Marshal.SizeOf(typeof(MONITORINFOEX));
                    if (!GetMonitorInfo(monitor, ref info)) return true;
                    DisplayInfo display = new DisplayInfo();
                    display.Device = info.szDevice;
                    display.Primary = (info.dwFlags & 1) != 0;
                    display.Bounds = Rectangle.FromLTRB(info.rcMonitor.Left, info.rcMonitor.Top, info.rcMonitor.Right, info.rcMonitor.Bottom);
                    string number = info.szDevice.Replace("\\\\.\\DISPLAY", "");
                    display.Label = "Écran " + number + (display.Primary ? " · principal" : "")
                        + "  —  " + display.Bounds.Width + " × " + display.Bounds.Height;
                    displays.Add(display);
                    return true;
                };
                if (!EnumDisplayMonitors(IntPtr.Zero, IntPtr.Zero, callback, IntPtr.Zero) || displays.Count == 0)
                    throw new InvalidOperationException("Windows ne renvoie aucun écran utilisable.");
            }
            displays.Sort(delegate(DisplayInfo a, DisplayInfo b)
            {
                if (a.Primary != b.Primary) return a.Primary ? -1 : 1;
                return String.Compare(a.Device, b.Device, StringComparison.OrdinalIgnoreCase);
            });
            return displays;
        }

        internal static Icon CreateIcon()
        {
            using (Bitmap bitmap = new Bitmap(32, 32))
            {
                using (Graphics g = Graphics.FromImage(bitmap))
                {
                    g.SmoothingMode = SmoothingMode.AntiAlias;
                    g.Clear(Color.Transparent);
                    using (Brush outer = new SolidBrush(Color.FromArgb(185, 175, 246))) g.FillEllipse(outer, 2, 2, 28, 28);
                    using (Brush inner = new SolidBrush(Color.FromArgb(32, 35, 43))) g.FillPie(inner, 5, 5, 22, 22, 90, 180);
                }
                IntPtr handle = bitmap.GetHicon();
                try { using (Icon original = Icon.FromHandle(handle)) return (Icon)original.Clone(); }
                finally { DestroyIcon(handle); }
            }
        }

        internal static void RaiseWithoutActivation(Form form)
        {
            if (form == null || form.IsDisposed || !form.Visible || !form.IsHandleCreated) return;
            SetWindowPos(form.Handle, HWND_TOPMOST, 0, 0, 0, 0,
                SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE | SWP_NOOWNERZORDER);
        }
    }

    internal sealed class OverlayWindow : Form
    {
        private Rectangle monitorBounds;
        internal Action DisplayChanged;
        internal OverlayWindow(DisplayInfo display)
        {
            monitorBounds = display.Bounds;
            AutoScaleMode = AutoScaleMode.None;
            FormBorderStyle = FormBorderStyle.None;
            StartPosition = FormStartPosition.Manual;
            ShowInTaskbar = false;
            Text = "Filtre Gris - " + display.Device;
            BackColor = Color.Black;
            Opacity = 0;
            TopMost = true;
            Bounds = monitorBounds;
            SetStyle(ControlStyles.Selectable, false);
            TabStop = false;
        }
        protected override bool ShowWithoutActivation { get { return true; } }
        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ExStyle |= Native.WS_EX_LAYERED | Native.WS_EX_TRANSPARENT
                    | Native.WS_EX_NOACTIVATE | Native.WS_EX_TOOLWINDOW;
                return cp;
            }
        }
        internal void Apply(int opacity, Color shade, bool enabled)
        {
            if (!enabled || opacity == 0)
            {
                if (Visible) Hide();
                return;
            }
            using (new DpiScope(Native.DPI_PER_MONITOR_V2))
            {
                BackColor = shade;
                Opacity = UserSettings.Clamp(opacity, 0, 90) / 100.0;
                if (!Visible) Show();
                Native.SetWindowPos(Handle, Native.HWND_TOPMOST, monitorBounds.X, monitorBounds.Y,
                    monitorBounds.Width, monitorBounds.Height, Native.SWP_NOACTIVATE | Native.SWP_NOOWNERZORDER);
            }
        }
        protected override void WndProc(ref Message m)
        {
            if (m.Msg == 0x0084) { m.Result = new IntPtr(-1); return; } // HTTRANSPARENT
            if (m.Msg == 0x0021) { m.Result = new IntPtr(3); return; } // MA_NOACTIVATE
            if (m.Msg == 0x02E0) // WM_DPICHANGED : recalculer le moniteur, pas le rect logique propose.
            {
                if (DisplayChanged != null) DisplayChanged();
                m.Result = IntPtr.Zero;
                return;
            }
            base.WndProc(ref m);
        }
    }

    internal sealed class ControlWindow : Form
    {
        private readonly EventWaitHandle showEvent;
        private readonly EventWaitHandle quitEvent;
        private readonly UserSettings settings;
        private readonly List<OverlayWindow> overlays = new List<OverlayWindow>();
        private readonly List<int> registeredHotkeys = new List<int>();
        private readonly List<string> unavailableHotkeys = new List<string>();
        private readonly System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();
        private readonly Color surface = Color.FromArgb(30, 34, 43);
        private readonly Color muted = Color.FromArgb(179, 185, 199);
        private readonly Color accent = Color.FromArgb(192, 181, 255);
        private List<DisplayInfo> displays;
        private TrackBar opacitySlider;
        private Label valueLabel, stateLabel, shortcutLabel, savedLabel;
        private ComboBox shadeCombo, monitorCombo;
        private Button toggleButton;
        private NotifyIcon tray;
        private ContextMenuStrip trayMenu;
        private ToolStripMenuItem trayToggle;
        private Icon appIcon;
        private bool building = true;
        private bool shuttingDown;
        private bool menuOpen;
        private volatile bool displayRefresh;
        private bool dirty;
        private long lastEdit;
        private int ticks;
        private string displaySignature = "";

        internal ControlWindow(EventWaitHandle show, EventWaitHandle quit)
        {
            showEvent = show;
            quitEvent = quit;
            settings = UserSettings.Load();
            Text = "Filtre gris";
            Font = new Font("Segoe UI", 10F);
            AutoScaleDimensions = new SizeF(7F, 17F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(19, 22, 29);
            ForeColor = Color.FromArgb(241, 241, 248);
            StartPosition = FormStartPosition.CenterScreen;
            ClientSize = new Size(552, 650);
            MinimumSize = new Size(500, 530);
            MaximizeBox = false;
            TopMost = true;
            appIcon = Native.CreateIcon();
            Icon = appIcon;
            BuildInterface();
            BuildTray();
            RefreshDisplays(true);
            building = false;
            timer.Interval = 250;
            timer.Tick += Heartbeat;
            SystemEvents.DisplaySettingsChanged += OnDisplaysChanged;
            SystemEvents.PowerModeChanged += OnPowerChanged;
            SystemEvents.SessionSwitch += OnSessionChanged;
            UpdateInterface();
        }

        private void BuildInterface()
        {
            Panel scroll = new Panel();
            scroll.Dock = DockStyle.Fill;
            scroll.AutoScroll = true;
            Controls.Add(scroll);
            TableLayoutPanel root = new TableLayoutPanel();
            root.Dock = DockStyle.Top;
            root.AutoSize = true;
            root.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            root.ColumnCount = 1;
            root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            root.Padding = new Padding(22, 18, 22, 20);
            scroll.Controls.Add(root);

            Label title = MakeLabel("Filtre gris", 25, ForeColor);
            title.Font = new Font("Segoe UI Semibold", 25F);
            AddRow(root, title);
            AddRow(root, MakeLabel("Dose la lumière. Garde le contrôle.", 10, muted));
            stateLabel = MakeLabel("Filtre actif", 10, accent);
            stateLabel.Margin = new Padding(0, 10, 0, 14);
            AddRow(root, stateLabel);

            TableLayoutPanel card = new TableLayoutPanel();
            card.AutoSize = true;
            card.Dock = DockStyle.Fill;
            card.ColumnCount = 1;
            card.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            card.BackColor = surface;
            card.Padding = new Padding(16, 12, 16, 14);
            AddRow(root, card);

            TableLayoutPanel readout = new TableLayoutPanel();
            readout.AutoSize = true;
            readout.Dock = DockStyle.Fill;
            readout.ColumnCount = 2;
            readout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 65));
            readout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 35));
            Label caption = MakeLabel("OPACITÉ DU FILTRE", 9, muted);
            caption.Anchor = AnchorStyles.Left;
            readout.Controls.Add(caption, 0, 0);
            valueLabel = MakeLabel(settings.Opacity + " %", 25, accent);
            valueLabel.Anchor = AnchorStyles.Right;
            readout.Controls.Add(valueLabel, 1, 0);
            AddRow(card, readout);

            opacitySlider = new TrackBar();
            opacitySlider.Minimum = 0;
            opacitySlider.Maximum = 90;
            opacitySlider.SmallChange = 1;
            opacitySlider.LargeChange = 5;
            opacitySlider.TickStyle = TickStyle.None;
            opacitySlider.Value = settings.Opacity;
            opacitySlider.Dock = DockStyle.Fill;
            opacitySlider.BackColor = surface;
            opacitySlider.AccessibleName = "Opacité du filtre, de zéro à quatre-vingt-dix pour cent";
            opacitySlider.ValueChanged += delegate
            {
                if (building) return;
                settings.Opacity = opacitySlider.Value;
                settings.Enabled = true;
                Changed();
            };
            AddRow(card, opacitySlider);
            AddRow(card, MakeLabel("0 % : aucun filtre     ·     90 % : très sombre", 9, muted));

            FlowLayoutPanel presets = new FlowLayoutPanel();
            presets.AutoSize = true;
            presets.Dock = DockStyle.Fill;
            presets.Margin = new Padding(0, 12, 0, 0);
            AddPreset(presets, "Léger 20 %", 20);
            AddPreset(presets, "Doux 35 %", 35);
            AddPreset(presets, "Sombre 55 %", 55);
            AddPreset(presets, "Nuit 75 %", 75);
            AddRow(card, presets);

            Label shadeLabel = MakeLabel("Couleur du filtre", 10, muted);
            shadeLabel.Margin = new Padding(0, 16, 0, 4);
            AddRow(root, shadeLabel);
            shadeCombo = MakeCombo();
            shadeCombo.Items.AddRange(new object[] { "Noir neutre — assombrissement maximal", "Gris anthracite — voile gris très sombre", "Gris foncé — voile gris plus visible" });
            shadeCombo.SelectedIndex = settings.Shade;
            shadeCombo.SelectedIndexChanged += delegate
            {
                if (building) return;
                settings.Shade = shadeCombo.SelectedIndex;
                Changed();
            };
            AddRow(root, shadeCombo);

            Label monitorLabel = MakeLabel("Appliquer sur", 10, muted);
            monitorLabel.Margin = new Padding(0, 12, 0, 4);
            AddRow(root, monitorLabel);
            monitorCombo = MakeCombo();
            monitorCombo.SelectedIndexChanged += delegate
            {
                if (building || monitorCombo.SelectedItem == null) return;
                settings.Monitor = ((DisplayInfo)monitorCombo.SelectedItem).Device;
                RebuildFilters();
                Changed();
            };
            AddRow(root, monitorCombo);

            FlowLayoutPanel actions = new FlowLayoutPanel();
            actions.AutoSize = true;
            actions.Dock = DockStyle.Fill;
            actions.Margin = new Padding(0, 17, 0, 6);
            toggleButton = MakeButton("Mettre en pause", true);
            toggleButton.Click += delegate { Toggle(); };
            actions.Controls.Add(toggleButton);
            Button hide = MakeButton("Masquer la fenêtre", false);
            hide.Click += delegate { HidePanel(); };
            actions.Controls.Add(hide);
            Button stop = MakeButton("Quitter", false);
            stop.Click += delegate { Close(); };
            actions.Controls.Add(stop);
            AddRow(root, actions);

            shortcutLabel = MakeLabel("", 9, muted);
            shortcutLabel.Margin = new Padding(0, 8, 0, 4);
            AddRow(root, shortcutLabel);
            Label restore = MakeLabel("Fenêtre masquée ? Clique sur l’icône près de l’horloge\r\nou relance LANCER.bat. Fermer avec × retire le filtre.", 9, muted);
            restore.Margin = new Padding(0, 6, 0, 0);
            AddRow(root, restore);
            savedLabel = MakeLabel("Réglages mémorisés automatiquement.", 8, muted);
            savedLabel.Margin = new Padding(0, 12, 0, 0);
            AddRow(root, savedLabel);
        }

        private Label MakeLabel(string text, float size, Color color)
        {
            Label label = new Label();
            label.Text = text;
            label.AutoSize = true;
            label.Font = new Font("Segoe UI", size);
            label.ForeColor = color;
            label.Margin = new Padding(0, 0, 0, 3);
            return label;
        }
        private static void AddRow(TableLayoutPanel table, Control control)
        {
            int row = table.RowCount++;
            table.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            table.Controls.Add(control, 0, row);
        }
        private ComboBox MakeCombo()
        {
            ComboBox combo = new ComboBox();
            combo.DropDownStyle = ComboBoxStyle.DropDownList;
            combo.FlatStyle = FlatStyle.Flat;
            combo.BackColor = surface;
            combo.ForeColor = ForeColor;
            combo.Dock = DockStyle.Fill;
            combo.DropDownWidth = 570;
            combo.Margin = new Padding(0);
            return combo;
        }
        private Button MakeButton(string text, bool primary)
        {
            Button button = new Button();
            button.Text = text;
            button.AutoSize = true;
            button.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            button.FlatStyle = FlatStyle.Flat;
            button.FlatAppearance.BorderSize = 0;
            button.BackColor = primary ? accent : surface;
            button.ForeColor = primary ? Color.FromArgb(27, 24, 37) : ForeColor;
            button.Padding = new Padding(8, 5, 8, 5);
            button.Margin = new Padding(0, 0, 8, 6);
            button.Cursor = Cursors.Hand;
            return button;
        }
        private void AddPreset(FlowLayoutPanel row, string title, int value)
        {
            Button button = MakeButton(title, false);
            button.Font = new Font("Segoe UI", 9);
            button.BackColor = Color.FromArgb(43, 48, 60);
            button.Padding = new Padding(4, 3, 4, 3);
            button.Click += delegate { SetOpacity(value); };
            row.Controls.Add(button);
        }

        private void BuildTray()
        {
            trayMenu = new ContextMenuStrip();
            trayMenu.Opening += delegate { menuOpen = true; };
            trayMenu.Closed += delegate { menuOpen = false; };
            trayMenu.Items.Add("Ouvrir les réglages", null, delegate { ShowPanel(); });
            trayToggle = new ToolStripMenuItem("Mettre en pause", null, delegate { Toggle(); });
            trayMenu.Items.Add(trayToggle);
            trayMenu.Items.Add("Assombrir (+5 %)", null, delegate { SetOpacity(settings.Opacity + 5); });
            trayMenu.Items.Add("Éclaircir (-5 %)", null, delegate { SetOpacity(settings.Opacity - 5); });
            trayMenu.Items.Add(new ToolStripSeparator());
            trayMenu.Items.Add("Quitter et retirer le filtre", null, delegate { Close(); });
            tray = new NotifyIcon();
            tray.Icon = appIcon;
            tray.Text = "Filtre gris";
            tray.ContextMenuStrip = trayMenu;
            tray.MouseClick += delegate(object sender, MouseEventArgs e)
            {
                if (e.Button == MouseButtons.Left) ShowPanel();
            };
            tray.Visible = true;
        }

        protected override void OnShown(EventArgs e)
        {
            base.OnShown(e);
            RebuildFilters();
            ApplyFilters();
            UpdateInterface();
            timer.Start();
        }
        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);
            if (!building && WindowState == FormWindowState.Minimized) HidePanel();
        }
        internal void ShowPanel()
        {
            if (shuttingDown) return;
            using (new DpiScope(Native.DPI_SYSTEM))
            {
                if (WindowState == FormWindowState.Minimized) WindowState = FormWindowState.Normal;
                if (!Visible) Show();
                // Le panneau reste recuperable apres le retrait d'un ecran.
                Rectangle work = Screen.FromControl(this).WorkingArea;
                int maxLeft = Math.Max(work.Left, work.Right - Width);
                int maxTop = Math.Max(work.Top, work.Bottom - Height);
                Location = new Point(Math.Max(work.Left, Math.Min(Left, maxLeft)),
                    Math.Max(work.Top, Math.Min(Top, maxTop)));
                Native.RaiseWithoutActivation(this);
                Activate();
            }
        }
        private void HidePanel()
        {
            if (shuttingDown) return;
            Hide();
            if (WindowState == FormWindowState.Minimized) WindowState = FormWindowState.Normal;
        }
        private void Toggle()
        {
            settings.Enabled = !settings.Enabled;
            Changed();
        }
        private void SetOpacity(int value)
        {
            settings.Opacity = UserSettings.Clamp(value, 0, 90);
            settings.Enabled = true;
            building = true;
            opacitySlider.Value = settings.Opacity;
            building = false;
            Changed();
        }
        private void Changed()
        {
            dirty = true;
            lastEdit = Stopwatch.GetTimestamp();
            ApplyFilters();
            UpdateInterface();
        }

        private void RefreshDisplays(bool force)
        {
            List<DisplayInfo> refreshed = Native.GetDisplays();
            StringBuilder signature = new StringBuilder();
            foreach (DisplayInfo display in refreshed)
                signature.Append(display.Device).Append(display.Bounds.ToString()).Append(display.Primary);
            if (!force && signature.ToString() == displaySignature) return;
            displays = refreshed;
            displaySignature = signature.ToString();
            bool wasBuilding = building;
            building = true;
            try
            {
                monitorCombo.Items.Clear();
                monitorCombo.Items.Add(new DisplayInfo { Device = "all", Label = "Tous les écrans" });
                int selected = 0;
                foreach (DisplayInfo display in displays)
                {
                    int index = monitorCombo.Items.Add(display);
                    if (String.Equals(display.Device, settings.Monitor, StringComparison.OrdinalIgnoreCase)) selected = index;
                }
                monitorCombo.SelectedIndex = selected;
                if (selected == 0) settings.Monitor = "all";
            }
            finally { building = wasBuilding; }
            if (!building)
            {
                RebuildFilters();
                ApplyFilters();
                if (Visible) ShowPanel();
            }
        }

        private void RebuildFilters()
        {
            RemoveFilters();
            using (new DpiScope(Native.DPI_PER_MONITOR_V2))
            {
                foreach (DisplayInfo display in displays)
                {
                    if (settings.Monitor != "all" && !String.Equals(settings.Monitor, display.Device, StringComparison.OrdinalIgnoreCase)) continue;
                    OverlayWindow overlay = new OverlayWindow(display);
                    overlay.DisplayChanged = delegate { displayRefresh = true; };
                    overlays.Add(overlay);
                }
            }
        }
        private void ApplyFilters()
        {
            int level = settings.Shade == 0 ? 0 : (settings.Shade == 1 ? 16 : 32);
            Color shade = Color.FromArgb(level, level, level);
            foreach (OverlayWindow overlay in overlays) overlay.Apply(settings.Opacity, shade, settings.Enabled);
            if (Visible) Native.RaiseWithoutActivation(this);
        }
        internal void RemoveFilters()
        {
            foreach (OverlayWindow overlay in overlays)
            {
                overlay.DisplayChanged = null;
                overlay.Hide();
                overlay.Dispose();
            }
            overlays.Clear();
        }
        private void UpdateInterface()
        {
            if (valueLabel == null) return;
            valueLabel.Text = settings.Opacity + " %";
            stateLabel.Text = !settings.Enabled ? "En pause · affichage normal"
                : settings.Opacity == 0 ? "0 % · affichage normal" : "Filtre actif · réglage en temps réel";
            toggleButton.Text = settings.Enabled ? "Mettre en pause" : "Réactiver le filtre";
            if (trayToggle != null) trayToggle.Text = toggleButton.Text;
            if (tray != null) tray.Text = "Filtre gris · " + (settings.Enabled ? settings.Opacity + " %" : "en pause");
            UpdateShortcuts();
        }
        private void UpdateShortcuts()
        {
            if (shortcutLabel == null) return;
            string text = "Ctrl + Alt + ↑ / ↓ : régler par pas de 5 %\r\n"
                + "Ctrl + Alt + F8 : pause    ·    Ctrl + Alt + F9 : réglages\r\n"
                + "Ctrl + Alt + F11 : quitter immédiatement";
            if (unavailableHotkeys.Count > 0)
                text += "\r\nIndisponible(s) : " + String.Join(", ", unavailableHotkeys.ToArray())
                    + ".\r\nUtilise les boutons ou ARRETER.bat.";
            shortcutLabel.Text = text;
        }

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            unavailableHotkeys.Clear();
            Register(1, Keys.F8, "Ctrl+Alt+F8");
            Register(2, Keys.F9, "Ctrl+Alt+F9");
            Register(3, Keys.F11, "Ctrl+Alt+F11");
            Register(4, Keys.Up, "Ctrl+Alt+↑");
            Register(5, Keys.Down, "Ctrl+Alt+↓");
            UpdateShortcuts();
        }
        private void Register(int id, Keys key, string name)
        {
            if (Native.RegisterHotKey(Handle, id, 0x0001 | 0x0002 | 0x4000, (uint)key)) registeredHotkeys.Add(id);
            else unavailableHotkeys.Add(name);
        }
        protected override void OnHandleDestroyed(EventArgs e)
        {
            foreach (int id in registeredHotkeys) Native.UnregisterHotKey(Handle, id);
            registeredHotkeys.Clear();
            base.OnHandleDestroyed(e);
        }
        protected override void WndProc(ref Message m)
        {
            if (m.Msg == 0x0312 && !shuttingDown) // WM_HOTKEY
            {
                switch (m.WParam.ToInt32())
                {
                    case 1: Toggle(); break;
                    case 2: ShowPanel(); break;
                    case 3: Close(); break;
                    case 4: SetOpacity(settings.Opacity + 5); break;
                    case 5: SetOpacity(settings.Opacity - 5); break;
                }
                return;
            }
            if (m.Msg == 0x007E) displayRefresh = true; // WM_DISPLAYCHANGE
            base.WndProc(ref m);
        }
        private void OnDisplaysChanged(object sender, EventArgs e) { displayRefresh = true; }
        private void OnPowerChanged(object sender, PowerModeChangedEventArgs e)
        {
            if (e.Mode == PowerModes.Resume) displayRefresh = true;
        }
        private void OnSessionChanged(object sender, SessionSwitchEventArgs e)
        {
            if (e.Reason == SessionSwitchReason.SessionUnlock || e.Reason == SessionSwitchReason.SessionLogon)
                displayRefresh = true;
        }
        private void Heartbeat(object sender, EventArgs e)
        {
            if (shuttingDown) return;
            if (quitEvent.WaitOne(0)) { Close(); return; }
            if (showEvent.WaitOne(0)) ShowPanel();
            if (displayRefresh)
            {
                displayRefresh = false;
                RefreshDisplays(true);
            }
            if (dirty && (Stopwatch.GetTimestamp() - lastEdit) / (double)Stopwatch.Frequency > 0.8)
            {
                dirty = false;
                savedLabel.Text = settings.Save() ? "Réglages mémorisés automatiquement."
                    : "Réglages actifs pour cette session ; enregistrement impossible.";
            }
            // Quatre reveils legers par seconde pour les commandes, aucun dessin en boucle.
            // La remise au premier plan n'active jamais les fenetres du filtre.
            ticks++;
            if (ticks % 8 == 0 && !menuOpen && !shadeCombo.DroppedDown
                && !monitorCombo.DroppedDown && settings.Enabled && settings.Opacity > 0)
            {
                foreach (OverlayWindow overlay in overlays) Native.RaiseWithoutActivation(overlay);
                Native.RaiseWithoutActivation(this);
            }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            Cleanup();
            base.OnFormClosing(e);
        }
        private void Cleanup()
        {
            if (shuttingDown) return;
            shuttingDown = true;
            timer.Stop();
            SystemEvents.DisplaySettingsChanged -= OnDisplaysChanged;
            SystemEvents.PowerModeChanged -= OnPowerChanged;
            SystemEvents.SessionSwitch -= OnSessionChanged;
            RemoveFilters();
            settings.Save();
            if (tray != null) { tray.Visible = false; tray.Dispose(); tray = null; }
        }
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                Cleanup();
                timer.Dispose();
                if (trayMenu != null) { trayMenu.Dispose(); trayMenu = null; }
            }
            base.Dispose(disposing);
            if (disposing && appIcon != null) { appIcon.Dispose(); appIcon = null; }
        }
    }
}
